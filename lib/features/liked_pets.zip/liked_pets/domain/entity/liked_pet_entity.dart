class LikedPetEntity {
  // final String? userId;
  final String? petId;
  final String name;
  final String age;
  final String species;
  final String breed;
  final String gender;
  final String description;
  final String? color;
  final String? image;

  LikedPetEntity({
    // this.userId,
    this.petId,
    required this.name,
    required this.age,
    required this.species,
    required this.breed,
    required this.gender,
    required this.description,
    this.color,
    this.image,
  });
}
